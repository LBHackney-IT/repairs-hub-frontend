import easySoapRequest from 'easy-soap-request'

export const soapRequest = async (options) => await easySoapRequest(options)
