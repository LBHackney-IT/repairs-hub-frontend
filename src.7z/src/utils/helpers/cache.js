export const CACHE_MAX_SIZE = 500

export const CACHE_MAX_AGE_IN_MS = 300000 // 5 minutes

export const CACHE_MAX_AGE_IN_SECONDS = CACHE_MAX_AGE_IN_MS / 1000
