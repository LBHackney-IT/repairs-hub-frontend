export const lowPriorityHolidays = ['2021-12-29', '2021-12-30', '2021-12-31']
