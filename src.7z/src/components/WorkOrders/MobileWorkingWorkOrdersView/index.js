export { default } from './CurrentUserWrapper'
