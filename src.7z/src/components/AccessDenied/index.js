const AccessDenied = () => (
  <>
    <h1 className="lbh-heading-1">Access denied</h1>
  </>
)

export default AccessDenied
