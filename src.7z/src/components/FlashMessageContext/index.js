import { createContext } from 'react'

const FlashMessageContext = createContext()

export default FlashMessageContext
